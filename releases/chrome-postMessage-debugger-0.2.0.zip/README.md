# chrome-postMessage-debugger

This chrome extension prints messages sent with postMessage to the console for debugging.
